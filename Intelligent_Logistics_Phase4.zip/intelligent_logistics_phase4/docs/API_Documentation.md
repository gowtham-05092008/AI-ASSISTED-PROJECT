# API Documentation

FastAPI automatically publishes interactive OpenAPI documentation at `/docs`.

Important endpoints:
- GET `/api/health`
- POST `/api/auth/login`
- POST `/api/shipments`
- GET `/api/shipments`
- GET `/api/tracking/{tracking_code}`
- POST `/api/pickups`
- PATCH `/api/shipments/{tracking_code}/status`
- POST `/api/dispatch/recommend/{tracking_code}`
- GET `/api/notifications`
- POST `/api/messages`
- GET `/api/messages/{tracking_code}`
- GET `/api/fleet`
- GET `/api/warehouses`
