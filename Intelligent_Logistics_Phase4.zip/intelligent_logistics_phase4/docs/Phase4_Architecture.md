# Phase 4 Architecture

The system uses a two-process full-stack architecture:
1. Streamlit provides the responsive web UI.
2. FastAPI exposes RESTful business APIs.
3. SQLAlchemy maps business entities to SQLite.
4. Services create notifications and delivery events.
5. The intelligence layer recommends compatible driver/vehicle assignments.
