# Testing

Run:
```powershell
pytest
```

The suite validates API health, login and fleet retrieval. Additional tests should be added for
shipment creation, tracking, pickup scheduling, notifications, collaboration and authorization.
