
def recommend_assignment(db, weight_kg, region=None, distance_km=0):
    from database.models import Vehicle, Driver
    vehicles = db.query(Vehicle).filter(
        Vehicle.status == "Available",
        Vehicle.capacity_kg >= float(weight_kg or 0)
    ).all()
    candidates = []
    for vehicle in vehicles:
        driver = db.query(Driver).filter(
            Driver.vehicle_id == vehicle.id,
            Driver.status == "Available"
        ).first()
        if not driver:
            continue
        score = 50
        if region and vehicle.region and vehicle.region.lower() == region.lower():
            score += 20
        if region and driver.region and driver.region.lower() == region.lower():
            score += 20
        utilization_penalty = abs(vehicle.capacity_kg - float(weight_kg or 0)) / max(vehicle.capacity_kg, 1)
        score += max(0, 10 - utilization_penalty * 10)
        if distance_km > 100 and vehicle.vehicle_type.lower() in ("van", "truck"):
            score += 5
        candidates.append((round(score, 2), vehicle, driver))
    return max(candidates, key=lambda x: x[0]) if candidates else None
