
import streamlit as st
import requests

API = "http://127.0.0.1:8000"

st.set_page_config(page_title="Logistics Customer Portal", page_icon="📦", layout="wide")
st.title("📦 Logistics Operations & Customer Collaboration Portal")
st.caption("Phase 4 — customer shipment requests, tracking, pickups, notifications and collaboration")

with st.sidebar:
    st.header("Portal")
    module = st.radio("Choose", ["Dashboard", "Place Shipment", "Track Delivery", "Schedule Pickup", "Notifications", "Collaboration"])

def api(method, path, **kwargs):
    try:
        r = requests.request(method, API + path, timeout=5, **kwargs)
        if r.ok: return r.json()
        st.error(f"API error {r.status_code}: {r.text}")
    except requests.RequestException:
        st.error("API is not running. Start it with: python -m uvicorn api.main:app --reload")
    return None

if module == "Dashboard":
    st.subheader("Customer Dashboard")
    ships = api("GET", "/api/shipments") or []
    notifs = api("GET", "/api/notifications") or []
    a,b,c = st.columns(3)
    a.metric("Shipments", len(ships))
    b.metric("Notifications", len(notifs))
    c.metric("Active", sum(x["status"] not in ("Delivered","Cancelled") for x in ships))
    st.dataframe(ships, use_container_width=True, hide_index=True)

elif module == "Place Shipment":
    st.subheader("Create Shipment Request")
    with st.form("shipment"):
        customer = st.text_input("Customer Code", "CUST-DEMO")
        p1,p2=st.columns(2)
        pickup=p1.text_input("Pickup Address")
        delivery=p2.text_input("Delivery Address")
        package=st.text_input("Package Type", "General")
        weight=st.number_input("Weight (kg)", min_value=0.0, value=1.0)
        distance=st.number_input("Distance (km)", min_value=0.0, value=10.0)
        priority=st.selectbox("Priority", ["Normal","High","Urgent"])
        expected=st.date_input("Expected Delivery")
        if st.form_submit_button("Submit Shipment Request", type="primary"):
            result=api("POST","/api/shipments",json={
                "customer_code":customer,"pickup_address":pickup,
                "delivery_address":delivery,"package_type":package,
                "weight_kg":weight,"distance_km":distance,
                "priority":priority,"expected_delivery":str(expected)
            })
            if result:
                st.success(f"Shipment created: {result['tracking_code']}")

elif module == "Track Delivery":
    st.subheader("Track Your Delivery")
    tracking=st.text_input("Tracking Number")
    if st.button("Track") and tracking:
        result=api("GET",f"/api/tracking/{tracking}")
        if result:
            st.metric("Current Status",result["status"])
            if result.get("expected_delivery"): st.write("Expected:",result["expected_delivery"])
            for e in result["events"]:
                st.write(f"**{e['new_status']}** — {e['note'] or ''} — {e['created_at']}")
            st.divider()
            st.write("AI/dispatch recommendation:")
            rec=api("POST",f"/api/dispatch/recommend/{tracking}")
            if rec: st.info(f"{rec['driver_name']} + {rec['vehicle_code']} ({rec['vehicle_type']}) | Score {rec['score']}")

elif module == "Schedule Pickup":
    st.subheader("Schedule Pickup")
    tracking=st.text_input("Tracking Number")
    date=st.date_input("Pickup Date")
    slot=st.selectbox("Pickup Slot",["09:00–12:00","12:00–15:00","15:00–18:00"])
    address=st.text_input("Pickup Address")
    if st.button("Schedule Pickup", type="primary"):
        result=api("POST","/api/pickups",json={
            "tracking_code":tracking,"pickup_date":str(date),
            "pickup_slot":slot,"address":address
        })
        if result: st.success(result["message"])

elif module == "Notifications":
    st.subheader("🔔 Notifications")
    rows=api("GET","/api/notifications") or []
    for n in rows:
        with st.container(border=True):
            st.write(f"**{n['title']}**")
            st.write(n["message"])
            st.caption(n["created_at"])

else:
    st.subheader("💬 Shipment Collaboration")
    tracking=st.text_input("Tracking Number")
    if tracking:
        rows=api("GET",f"/api/messages/{tracking}") or []
        for m in rows:
            st.write(f"**{m['sender_name']} ({m['sender_role']})**: {m['message']}")
        with st.form("message"):
            name=st.text_input("Your Name")
            role=st.selectbox("Role",["Customer","Logistics Manager","Warehouse Staff","Driver"])
            msg=st.text_area("Message")
            if st.form_submit_button("Send Message"):
                result=api("POST","/api/messages",json={
                    "tracking_code":tracking,"sender_name":name,
                    "sender_role":role,"message":msg
                })
                if result: st.success("Message sent.")
