# Phase 4 — Logistics Operations & Customer Collaboration Portal

## Components
- FastAPI REST backend
- Streamlit customer/operations portal
- SQLite + SQLAlchemy persistence
- Customer shipment requests
- Delivery tracking and status events
- Pickup scheduling
- Notifications
- Shipment collaboration/messages
- Fleet and warehouse API endpoints
- Intelligent driver/vehicle recommendation
- Automated API tests

## Run

Terminal 1:
```powershell
python -m pip install -r requirements.txt
python -m uvicorn api.main:app --reload
```

Terminal 2:
```powershell
python -m streamlit run frontend/portal.py
```

API docs:
`http://127.0.0.1:8000/docs`

Portal:
`http://localhost:8501`

## Demo accounts
Admin: admin@logistics.local / admin123
Customer: customer@logistics.local / customer123

For a production system, passwords must be hashed and JWT/OAuth2 should replace this demonstration login.
