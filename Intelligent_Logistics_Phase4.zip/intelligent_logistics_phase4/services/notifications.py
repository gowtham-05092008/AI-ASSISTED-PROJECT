
from database.models import Notification

def create_notification(db, title, message, user_id=None, shipment_id=None):
    n = Notification(user_id=user_id, shipment_id=shipment_id,
                     title=title, message=message)
    db.add(n)
    db.commit()
    db.refresh(n)
    return n
