
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_login():
    r = client.post("/api/auth/login", json={
        "email": "admin@logistics.local", "password": "admin123"
    })
    assert r.status_code == 200
    assert r.json()["role"] == "admin"

def test_fleet_endpoint():
    r = client.get("/api/fleet")
    assert r.status_code == 200
    assert isinstance(r.json(), list)
