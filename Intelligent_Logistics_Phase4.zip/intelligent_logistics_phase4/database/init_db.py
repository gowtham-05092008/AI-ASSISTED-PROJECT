
from .database import engine, Base, SessionLocal
from .models import User, Customer, Vehicle, Driver, Warehouse

def init_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if not db.query(User).filter_by(email="admin@logistics.local").first():
            db.add(User(name="System Admin", email="admin@logistics.local",
                        password="admin123", role="admin"))
        if not db.query(User).filter_by(email="customer@logistics.local").first():
            u = User(name="Demo Customer", email="customer@logistics.local",
                     password="customer123", role="customer")
            db.add(u)
            db.flush()
            db.add(Customer(user_id=u.id, customer_code="CUST-DEMO",
                            name="Demo Customer", phone="9000000000",
                            address="Hyderabad"))
        if db.query(Vehicle).count() == 0:
            for i, (vt, cap) in enumerate([("Bike", 50), ("Van", 500), ("Truck", 2000)], 1):
                for j in range(1, 3):
                    v = Vehicle(vehicle_code=f"VH-{i}-{j}", vehicle_type=vt,
                                capacity_kg=cap, region="General",
                                registration_no=f"REG-{i}-{j}",
                                status="Available")
                    db.add(v)
                    db.flush()
                    db.add(Driver(driver_code=f"DRV-{i}-{j}",
                                   name=f"Driver {i}-{j}", phone="9000000000",
                                   region="General", status="Available",
                                   vehicle_id=v.id))
        if db.query(Warehouse).count() == 0:
            db.add(Warehouse(warehouse_code="WH-001", name="Main Warehouse",
                             location="Hyderabad", capacity=10000, occupancy=0))
        db.commit()
    finally:
        db.close()
