
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password = Column(String(255), nullable=False)
    role = Column(String(40), default="customer", index=True)

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    customer_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30))
    address = Column(String(300))

class Vehicle(Base):
    __tablename__ = "vehicles"
    id = Column(Integer, primary_key=True)
    vehicle_code = Column(String(50), unique=True, nullable=False)
    vehicle_type = Column(String(50), nullable=False)
    capacity_kg = Column(Float, default=0)
    region = Column(String(100))
    status = Column(String(30), default="Available")
    registration_no = Column(String(50), unique=True)

class Driver(Base):
    __tablename__ = "drivers"
    id = Column(Integer, primary_key=True)
    driver_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30))
    region = Column(String(100))
    status = Column(String(30), default="Available")
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=True)

class Warehouse(Base):
    __tablename__ = "warehouses"
    id = Column(Integer, primary_key=True)
    warehouse_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    location = Column(String(200))
    capacity = Column(Float, default=0)
    occupancy = Column(Float, default=0)
    status = Column(String(30), default="Active")

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    order_code = Column(String(50), unique=True, nullable=False, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"))
    pickup_address = Column(String(300))
    delivery_address = Column(String(300))
    package_type = Column(String(100))
    weight_kg = Column(Float, default=0)
    distance_km = Column(Float, default=0)
    priority = Column(String(30), default="Normal")
    status = Column(String(50), default="Created", index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Shipment(Base):
    __tablename__ = "shipments"
    id = Column(Integer, primary_key=True)
    tracking_code = Column(String(80), unique=True, nullable=False, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), unique=True)
    status = Column(String(50), default="Shipment Requested", index=True)
    expected_delivery = Column(String(30))
    created_at = Column(DateTime, default=datetime.utcnow)

class PickupRequest(Base):
    __tablename__ = "pickup_requests"
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey("orders.id"))
    pickup_date = Column(String(30))
    pickup_slot = Column(String(50))
    address = Column(String(300))
    status = Column(String(40), default="Scheduled")
    created_at = Column(DateTime, default=datetime.utcnow)

class Dispatch(Base):
    __tablename__ = "dispatches"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"))
    driver_id = Column(Integer, ForeignKey("drivers.id"))
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"))
    status = Column(String(40), default="Dispatched")
    notes = Column(Text)
    dispatched_at = Column(DateTime, default=datetime.utcnow)

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"), nullable=True)
    title = Column(String(150), nullable=False)
    message = Column(Text, nullable=False)
    read = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"), nullable=True)
    sender_name = Column(String(150), nullable=False)
    sender_role = Column(String(40), nullable=False)
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class DeliveryEvent(Base):
    __tablename__ = "delivery_events"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"))
    old_status = Column(String(50))
    new_status = Column(String(50))
    note = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
