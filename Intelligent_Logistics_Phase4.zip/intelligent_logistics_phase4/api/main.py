
from datetime import datetime
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from database.database import engine, Base, get_db
from database.models import User, Customer, Order, Shipment, PickupRequest, Notification, Message, DeliveryEvent, Vehicle, Driver, Warehouse
from database.init_db import init_database
from services.notifications import create_notification
from intelligence.assignment import recommend_assignment

init_database()
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Intelligent Logistics API", version="1.0.0")

class LoginRequest(BaseModel):
    email: str
    password: str

class ShipmentRequest(BaseModel):
    customer_code: str
    pickup_address: str
    delivery_address: str
    package_type: str = "General"
    weight_kg: float = Field(ge=0)
    distance_km: float = Field(ge=0)
    priority: str = "Normal"
    expected_delivery: Optional[str] = None

class PickupRequestBody(BaseModel):
    tracking_code: str
    pickup_date: str
    pickup_slot: str
    address: str

class StatusUpdate(BaseModel):
    status: str
    note: str = ""

class MessageBody(BaseModel):
    tracking_code: str
    sender_name: str
    sender_role: str
    message: str

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "Intelligent Logistics API"}

@app.post("/api/auth/login")
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=body.email, password=body.password).first()
    if not user:
        raise HTTPException(401, "Invalid email or password")
    return {"user_id": user.id, "name": user.name, "role": user.role}

@app.post("/api/shipments")
def create_shipment(body: ShipmentRequest, db: Session = Depends(get_db)):
    customer = db.query(Customer).filter_by(customer_code=body.customer_code).first()
    if not customer:
        raise HTTPException(404, "Customer not found")
    order_code = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    order = Order(order_code=order_code, customer_id=customer.id,
                  pickup_address=body.pickup_address,
                  delivery_address=body.delivery_address,
                  package_type=body.package_type,
                  weight_kg=body.weight_kg,
                  distance_km=body.distance_km,
                  priority=body.priority)
    db.add(order)
    db.flush()
    tracking = f"TRK-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    shipment = Shipment(tracking_code=tracking, order_id=order.id,
                        expected_delivery=body.expected_delivery)
    db.add(shipment)
    db.flush()
    db.add(DeliveryEvent(shipment_id=shipment.id, new_status="Shipment Requested",
                         note="Customer shipment request"))
    db.commit()
    return {"order_code": order_code, "tracking_code": tracking, "status": shipment.status}

@app.get("/api/shipments")
def list_shipments(db: Session = Depends(get_db)):
    rows = db.query(Shipment).order_by(Shipment.id.desc()).all()
    return [{"id": s.id, "tracking_code": s.tracking_code,
             "order_id": s.order_id, "status": s.status,
             "expected_delivery": s.expected_delivery} for s in rows]

@app.get("/api/tracking/{tracking_code}")
def track(tracking_code: str, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=tracking_code).first()
    if not s:
        raise HTTPException(404, "Tracking number not found")
    events = db.query(DeliveryEvent).filter_by(shipment_id=s.id).order_by(DeliveryEvent.id).all()
    return {"tracking_code": s.tracking_code, "status": s.status,
            "expected_delivery": s.expected_delivery,
            "events": [{"old_status": e.old_status, "new_status": e.new_status,
                        "note": e.note, "created_at": e.created_at.isoformat()} for e in events]}

@app.post("/api/pickups")
def schedule_pickup(body: PickupRequestBody, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=body.tracking_code).first()
    if not s:
        raise HTTPException(404, "Shipment not found")
    p = PickupRequest(order_id=s.order_id, pickup_date=body.pickup_date,
                      pickup_slot=body.pickup_slot, address=body.address)
    db.add(p)
    s.status = "Pickup Scheduled"
    db.add(DeliveryEvent(shipment_id=s.id, old_status="Shipment Requested",
                         new_status="Pickup Scheduled", note="Customer scheduled pickup"))
    db.commit()
    return {"message": "Pickup scheduled", "pickup_id": p.id, "tracking_code": s.tracking_code}

@app.patch("/api/shipments/{tracking_code}/status")
def update_status(tracking_code: str, body: StatusUpdate, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=tracking_code).first()
    if not s:
        raise HTTPException(404, "Shipment not found")
    old = s.status
    s.status = body.status
    db.add(DeliveryEvent(shipment_id=s.id, old_status=old,
                         new_status=body.status, note=body.note))
    db.commit()
    create_notification(db, "Shipment Update",
                        f"{tracking_code}: {old} → {body.status}",
                        shipment_id=s.id)
    return {"tracking_code": tracking_code, "old_status": old, "status": body.status}

@app.post("/api/dispatch/recommend/{tracking_code}")
def recommend(tracking_code: str, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=tracking_code).first()
    if not s:
        raise HTTPException(404, "Shipment not found")
    order = db.query(Order).filter_by(id=s.order_id).first()
    result = recommend_assignment(db, order.weight_kg, None, order.distance_km)
    if not result:
        raise HTTPException(409, "No compatible driver and vehicle available")
    score, vehicle, driver = result
    return {"score": score, "vehicle_code": vehicle.vehicle_code,
            "vehicle_type": vehicle.vehicle_type, "driver_code": driver.driver_code,
            "driver_name": driver.name}

@app.get("/api/notifications")
def notifications(db: Session = Depends(get_db)):
    rows = db.query(Notification).order_by(Notification.id.desc()).limit(100).all()
    return [{"id": n.id, "title": n.title, "message": n.message,
             "read": n.read, "created_at": n.created_at.isoformat()} for n in rows]

@app.post("/api/messages")
def add_message(body: MessageBody, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=body.tracking_code).first()
    if not s:
        raise HTTPException(404, "Shipment not found")
    m = Message(shipment_id=s.id, sender_name=body.sender_name,
                sender_role=body.sender_role, message=body.message)
    db.add(m); db.commit(); db.refresh(m)
    return {"id": m.id, "message": m.message, "created_at": m.created_at.isoformat()}

@app.get("/api/messages/{tracking_code}")
def get_messages(tracking_code: str, db: Session = Depends(get_db)):
    s = db.query(Shipment).filter_by(tracking_code=tracking_code).first()
    if not s:
        raise HTTPException(404, "Shipment not found")
    rows = db.query(Message).filter_by(shipment_id=s.id).order_by(Message.id).all()
    return [{"sender_name": m.sender_name, "sender_role": m.sender_role,
             "message": m.message, "created_at": m.created_at.isoformat()} for m in rows]

@app.get("/api/fleet")
def fleet(db: Session = Depends(get_db)):
    vehicles = db.query(Vehicle).all()
    return [{"vehicle_code": v.vehicle_code, "type": v.vehicle_type,
             "capacity_kg": v.capacity_kg, "status": v.status,
             "region": v.region} for v in vehicles]

@app.get("/api/warehouses")
def warehouses(db: Session = Depends(get_db)):
    rows = db.query(Warehouse).all()
    return [{"code": w.warehouse_code, "name": w.name,
             "location": w.location, "capacity": w.capacity,
             "occupancy": w.occupancy, "status": w.status} for w in rows]
