# Database Design

Core entities: customers, orders, warehouses, inventory, vehicles, drivers, shipments,
dispatches and status_history. Orders belong to customers; shipments belong to orders;
dispatches connect shipments with drivers and vehicles; status_history provides an audit trail.
