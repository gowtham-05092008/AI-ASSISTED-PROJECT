# Automated Testing

Run `pytest`. Tests cover the intelligent assignment engine and can be expanded for CRUD,
inventory validation, shipment lifecycle and dispatch transactions.
