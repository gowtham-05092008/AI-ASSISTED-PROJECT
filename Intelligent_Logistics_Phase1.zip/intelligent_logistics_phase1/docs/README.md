# Intelligent Shipment & Fleet Management — Phase 1

## Dataset
Initial source: Delivery_Logistics.csv
Rows available: 25,000
Columns: 15

## Stack
- Streamlit
- SQLite
- SQLAlchemy
- Pandas
- Pytest

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Test
```bash
pytest
```

## Phase 1 coverage
Customer orders, shipment records, warehouses, inventory foundation, vehicle fleet,
drivers, intelligent driver/vehicle assignment, dispatch, shipment status history,
persistent SQLite storage, analytics and automated testing.
