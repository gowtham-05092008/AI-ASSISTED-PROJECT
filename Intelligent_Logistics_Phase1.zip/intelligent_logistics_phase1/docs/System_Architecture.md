# System Architecture

Streamlit provides the presentation layer. SQLAlchemy provides the persistence layer over SQLite.
The intelligence layer scores compatible vehicles and drivers using capacity, regional match,
and vehicle suitability. Shipment dispatch writes the shipment, dispatch and status-history records
in the same database transaction.
