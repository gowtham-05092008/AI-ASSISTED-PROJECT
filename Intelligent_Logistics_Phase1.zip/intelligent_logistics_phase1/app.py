
import streamlit as st
import pandas as pd
from pathlib import Path
from datetime import datetime
from database.database import (
    init_db, SessionLocal, Customer, Order, Warehouse, Inventory,
    Vehicle, Driver, Shipment, Dispatch, StatusHistory
)
from intelligence.assignment_engine import find_best_assignment

st.set_page_config(page_title="Intelligent Logistics", page_icon="🚚", layout="wide")
init_db()

@st.cache_data
def source_data():
    p = Path(__file__).parent / "Delivery_Logistics.csv"
    if not p.exists(): return pd.DataFrame()
    d = pd.read_csv(p)
    d.columns = [c.strip().lower().replace(" ", "_") for c in d.columns]
    return d

def seed_from_csv():
    db = SessionLocal()
    try:
        if db.query(Order).count() > 0:
            return
        d = source_data()
        for i, r in d.head(500).iterrows():
            code = str(r.get("order_id", f"ORD-{i+1}"))
            if db.query(Order).filter_by(order_code=code).first(): continue
            cust_code = str(r.get("customer_id", f"CUST-{i+1}"))
            cust = db.query(Customer).filter_by(customer_code=cust_code).first()
            if not cust:
                cust = Customer(customer_code=cust_code, name=f"Customer {cust_code}")
                db.add(cust); db.flush()
            db.add(Order(
                order_code=code, customer_id=cust.id,
                package_type=str(r.get("package_type","General")),
                weight_kg=float(r.get("weight_kg",0) or 0),
                distance_km=float(r.get("distance_km",0) or 0),
                priority="High" if str(r.get("priority","")).lower()=="high" else "Normal",
                status=str(r.get("delivery_status","Created")).title()
            ))
        # Seed vehicle/driver pools
        vehicle_types = ["Bike", "Van", "Truck"]
        for i, vt in enumerate(vehicle_types, 1):
            for j in range(1, 4):
                code=f"VH-{i:02d}-{j:02d}"
                if not db.query(Vehicle).filter_by(vehicle_code=code).first():
                    cap={"Bike":50,"Van":500,"Truck":2000}[vt]
                    v=Vehicle(vehicle_code=code, vehicle_type=vt, capacity_kg=cap, status="Available", region="General", registration_no=f"REG-{i:02d}-{j:02d}")
                    db.add(v); db.flush()
                    db.add(Driver(driver_code=f"DRV-{i:02d}-{j:02d}", name=f"Driver {i}-{j}", region="General", status="Available", vehicle_id=v.id))
        db.commit()
    finally:
        db.close()

seed_from_csv()
db = SessionLocal()

st.sidebar.title("🚚 Intelligent Logistics")
page = st.sidebar.radio("Module", [
    "Dashboard","Customers & Orders","Warehouses & Inventory",
    "Fleet & Drivers","Shipment Dispatch","Tracking","Analytics"
])

if page == "Dashboard":
    st.title("Intelligent Shipment & Fleet Management")
    orders=db.query(Order).count(); shipments=db.query(Shipment).count()
    vehicles=db.query(Vehicle).count(); available=db.query(Vehicle).filter_by(status="Available").count()
    c=db.query(Customer).count(); drivers=db.query(Driver).count()
    a,b,c1,d,e,f=st.columns(6)
    a.metric("Orders",orders); b.metric("Shipments",shipments); c1.metric("Customers",c)
    d.metric("Vehicles",vehicles); e.metric("Available Vehicles",available); f.metric("Drivers",drivers)
    st.subheader("Shipment Status")
    q=pd.read_sql("SELECT status, COUNT(*) count FROM shipments GROUP BY status", db.bind)
    if not q.empty: st.bar_chart(q.set_index("status"))
    st.info("Intelligent assignment selects an available driver + vehicle using capacity, regional match and vehicle suitability.")

elif page == "Customers & Orders":
    st.title("👥 Customers & Orders")
    with st.form("new_order"):
        st.subheader("Create Customer Order")
        x,y,z=st.columns(3)
        code=x.text_input("Customer Code", f"CUST-{db.query(Customer).count()+1}")
        name=y.text_input("Customer Name")
        phone=z.text_input("Phone")
        p,q,r=st.columns(3)
        package=p.text_input("Package Type","General")
        weight=q.number_input("Weight (kg)",0.0,10000.0,1.0)
        distance=r.number_input("Distance (km)",0.0,10000.0,10.0)
        priority=st.selectbox("Priority",["Normal","High","Urgent"])
        if st.form_submit_button("Create Order"):
            cust=db.query(Customer).filter_by(customer_code=code).first()
            if not cust:
                cust=Customer(customer_code=code,name=name or code,phone=phone); db.add(cust); db.flush()
            order=Order(order_code=f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}",customer_id=cust.id,package_type=package,weight_kg=weight,distance_km=distance,priority=priority)
            db.add(order); db.commit(); st.success(f"Created {order.order_code}")
    orders=pd.read_sql("SELECT * FROM orders ORDER BY id DESC LIMIT 100", db.bind)
    st.dataframe(orders,use_container_width=True,hide_index=True)

elif page == "Warehouses & Inventory":
    st.title("🏭 Warehouses & Inventory")
    with st.form("warehouse"):
        code=st.text_input("Warehouse Code")
        name=st.text_input("Warehouse Name")
        loc=st.text_input("Location")
        cap=st.number_input("Capacity",0.0,1000000.0,1000.0)
        if st.form_submit_button("Add Warehouse"):
            db.add(Warehouse(warehouse_code=code,name=name,location=loc,capacity=cap)); db.commit(); st.success("Warehouse added.")
    st.dataframe(pd.read_sql("SELECT * FROM warehouses",db.bind),use_container_width=True,hide_index=True)

elif page == "Fleet & Drivers":
    st.title("🚛 Fleet & Driver Management")
    with st.form("vehicle"):
        code=st.text_input("Vehicle Code"); reg=st.text_input("Registration No")
        vt=st.selectbox("Vehicle Type",["Bike","Van","Truck"])
        cap=st.number_input("Capacity (kg)",0.0,100000.0,500.0)
        region=st.text_input("Region","General")
        if st.form_submit_button("Register Vehicle"):
            db.add(Vehicle(vehicle_code=code,registration_no=reg,vehicle_type=vt,capacity_kg=cap,region=region)); db.commit(); st.success("Vehicle registered.")
    st.subheader("Vehicles")
    st.dataframe(pd.read_sql("SELECT * FROM vehicles",db.bind),use_container_width=True,hide_index=True)
    st.subheader("Drivers")
    st.dataframe(pd.read_sql("SELECT * FROM drivers",db.bind),use_container_width=True,hide_index=True)

elif page == "Shipment Dispatch":
    st.title("📦 Intelligent Shipment Dispatch")
    orders=db.query(Order).filter(Order.shipment == None).order_by(Order.id.desc()).all()
    if not orders:
        st.success("No undispatched orders.")
    else:
        order=st.selectbox("Order",orders,format_func=lambda x:f"{x.order_code} | {x.package_type} | {x.weight_kg} kg")
        st.write({"Distance":order.distance_km,"Weight":order.weight_kg,"Priority":order.priority,"Status":order.status})
        if st.button("🤖 Find Best Driver + Vehicle",type="primary"):
            result=find_best_assignment(db,order.weight_kg,None,order.distance_km)
            if not result: st.error("No compatible available driver and vehicle found.")
            else:
                score, vehicle, driver=result
                st.session_state.assignment=(score,vehicle.id,driver.id)
                st.success(f"Recommended: {driver.name} + {vehicle.vehicle_code} ({vehicle.vehicle_type}) | Score {score:.1f}")
        if "assignment" in st.session_state and st.button("🚀 Dispatch Shipment"):
            score,vid,did=st.session_state.assignment
            tracking=f"TRK-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            shipment=Shipment(tracking_code=tracking,order_id=order.id,status="Dispatched")
            db.add(shipment); db.flush()
            db.add(Dispatch(shipment_id=shipment.id,driver_id=did,vehicle_id=vid,priority=order.priority,status="Dispatched"))
            db.add(StatusHistory(shipment_id=shipment.id,new_status="Dispatched",note="Intelligent assignment"))
            db.query(Vehicle).filter_by(id=vid).update({"status":"On Delivery"})
            db.query(Driver).filter_by(id=did).update({"status":"On Delivery"})
            order.status="Dispatched"; db.commit()
            del st.session_state.assignment
            st.success(f"Shipment dispatched. Tracking code: {tracking}")

elif page == "Tracking":
    st.title("📍 Shipment Tracking")
    shipments=db.query(Shipment).order_by(Shipment.id.desc()).all()
    if shipments:
        sh=st.selectbox("Shipment",shipments,format_func=lambda x:x.tracking_code)
        st.write(f"Current status: **{sh.status}**")
        new=st.selectbox("Update Status",["Shipment Requested","Ready for Dispatch","Dispatched","In Transit","Out for Delivery","Delivered","Delayed","Failed Delivery","Cancelled"])
        note=st.text_input("Update note")
        if st.button("Update Status"):
            old=sh.status; sh.status=new
            db.add(StatusHistory(shipment_id=sh.id,old_status=old,new_status=new,note=note))
            db.commit(); st.success(f"{sh.tracking_code}: {old} → {new}")
        history=pd.read_sql(f"SELECT * FROM status_history WHERE shipment_id={sh.id} ORDER BY id DESC",db.bind)
        st.dataframe(history,use_container_width=True,hide_index=True)
    else: st.info("No shipments yet.")

else:
    st.title("📊 Logistics Analytics")
    queries = {
        "Orders by Status":"SELECT status, COUNT(*) count FROM orders GROUP BY status",
        "Vehicle Utilization":"SELECT status, COUNT(*) count FROM vehicles GROUP BY status",
        "Shipments by Status":"SELECT status, COUNT(*) count FROM shipments GROUP BY status",
    }
    for title,sql in queries.items():
        st.subheader(title)
        q=pd.read_sql(sql,db.bind)
        st.dataframe(q,use_container_width=True,hide_index=True)
        if not q.empty: st.bar_chart(q.set_index(q.columns[0]))

db.close()
