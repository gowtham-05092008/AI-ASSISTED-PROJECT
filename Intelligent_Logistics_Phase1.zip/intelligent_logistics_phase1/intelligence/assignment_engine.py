
from sqlalchemy import and_
from database.database import Vehicle, Driver

def find_best_assignment(session, weight_kg, region=None, distance_km=0):
    vehicles = session.query(Vehicle).filter(
        Vehicle.status == "Available",
        Vehicle.capacity_kg >= float(weight_kg or 0)
    ).all()

    candidates = []
    for v in vehicles:
        driver = session.query(Driver).filter(
            Driver.status == "Available",
            Driver.vehicle_id == v.id
        ).first()
        if not driver:
            continue

        score = 0
        if region and v.region and str(v.region).lower() == str(region).lower():
            score += 40
        if region and driver.region and str(driver.region).lower() == str(region).lower():
            score += 30
        score += max(0, 20 - abs(v.capacity_kg - float(weight_kg or 0)) / max(v.capacity_kg, 1) * 20)
        if distance_km and distance_km > 100 and str(v.vehicle_type).lower() in {"van", "truck"}:
            score += 10

        candidates.append((score, v, driver))

    if not candidates:
        return None
    return max(candidates, key=lambda x: x[0])
