
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from datetime import datetime

DATABASE_URL = "sqlite:///logistics.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    customer_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30))
    email = Column(String(150))
    address = Column(String(300))
    orders = relationship("Order", back_populates="customer")

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    order_code = Column(String(50), unique=True, nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"))
    package_type = Column(String(100))
    weight_kg = Column(Float, default=0)
    distance_km = Column(Float, default=0)
    priority = Column(String(30), default="Normal")
    status = Column(String(50), default="Created")
    created_at = Column(DateTime, default=datetime.utcnow)
    customer = relationship("Customer", back_populates="orders")
    shipment = relationship("Shipment", back_populates="order", uselist=False)

class Warehouse(Base):
    __tablename__ = "warehouses"
    id = Column(Integer, primary_key=True)
    warehouse_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    location = Column(String(200))
    capacity = Column(Float, default=0)
    current_occupancy = Column(Float, default=0)
    status = Column(String(30), default="Active")

class Inventory(Base):
    __tablename__ = "inventory"
    id = Column(Integer, primary_key=True)
    product_code = Column(String(50), nullable=False)
    product_name = Column(String(150), nullable=False)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"))
    quantity = Column(Integer, default=0)
    reserved_quantity = Column(Integer, default=0)
    reorder_level = Column(Integer, default=10)

class Vehicle(Base):
    __tablename__ = "vehicles"
    id = Column(Integer, primary_key=True)
    vehicle_code = Column(String(50), unique=True, nullable=False)
    vehicle_type = Column(String(50), nullable=False)
    capacity_kg = Column(Float, default=0)
    region = Column(String(100))
    status = Column(String(30), default="Available")
    registration_no = Column(String(50), unique=True)

class Driver(Base):
    __tablename__ = "drivers"
    id = Column(Integer, primary_key=True)
    driver_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    phone = Column(String(30))
    region = Column(String(100))
    status = Column(String(30), default="Available")
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=True)

class Shipment(Base):
    __tablename__ = "shipments"
    id = Column(Integer, primary_key=True)
    tracking_code = Column(String(80), unique=True, nullable=False)
    order_id = Column(Integer, ForeignKey("orders.id"), unique=True)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"), nullable=True)
    scheduled_date = Column(String(30))
    scheduled_slot = Column(String(50))
    status = Column(String(50), default="Shipment Requested")
    order = relationship("Order", back_populates="shipment")

class Dispatch(Base):
    __tablename__ = "dispatches"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"))
    driver_id = Column(Integer, ForeignKey("drivers.id"))
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"))
    priority = Column(String(30), default="Normal")
    status = Column(String(50), default="Dispatched")
    notes = Column(Text)
    dispatched_at = Column(DateTime, default=datetime.utcnow)

class StatusHistory(Base):
    __tablename__ = "status_history"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"))
    old_status = Column(String(50))
    new_status = Column(String(50), nullable=False)
    changed_at = Column(DateTime, default=datetime.utcnow)
    note = Column(Text)

def init_db():
    Base.metadata.create_all(engine)
