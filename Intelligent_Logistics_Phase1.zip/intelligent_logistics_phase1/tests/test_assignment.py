
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parents[1]))
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.database import Base, Vehicle, Driver
from intelligence.assignment_engine import find_best_assignment

def test_assignment_selects_compatible_driver():
    engine=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine)
    s=Session()
    v=Vehicle(vehicle_code="V1",vehicle_type="Van",capacity_kg=500,status="Available",region="North",registration_no="R1")
    s.add(v); s.flush()
    s.add(Driver(driver_code="D1",name="Test Driver",status="Available",region="North",vehicle_id=v.id))
    s.commit()
    result=find_best_assignment(s,100,"North",50)
    assert result is not None
    assert result[1].vehicle_code=="V1"
